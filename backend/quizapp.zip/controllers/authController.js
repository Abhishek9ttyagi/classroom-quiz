// backend/controllers/authController.js
const passport = require('passport');

// @desc    Initiate Google OAuth flow
// @route   GET /api/auth/google
exports.googleAuth = (req, res, next) => {
    const role = req.query.role; // Get role from query param ('teacher' or 'student')

    if (!role || (role !== 'teacher' && role !== 'student')) {
        return res.status(400).redirect(`${process.env.CLIENT_URL}/login?error=Role%20selection%20required`);
    }

    // Store the selected role temporarily in the session before redirecting to Google
    req.session.authRole = role;

    passport.authenticate('google', {
        scope: ['profile', 'email'],
        // Optionally add prompt: 'select_account' if you always want account chooser
    })(req, res, next);
};

// @desc    Google OAuth callback
// @route   GET /api/auth/google/callback
exports.googleCallback = (req, res, next) => {
    passport.authenticate('google', (err, user, info) => {
        if (err) {
            console.error("Google callback error:", err.message);
            // Redirect to frontend login page with error message
            return res.redirect(`${process.env.CLIENT_URL}/login?error=${encodeURIComponent(err.message)}`);
        }
        if (!user) {
            // Authentication failed (e.g., user denied permission)
             return res.redirect(`${process.env.CLIENT_URL}/login?error=Authentication%20failed`);
        }

        // Authentication successful, log the user in (Passport handles session setup)
        req.logIn(user, (loginErr) => {
            if (loginErr) {
                console.error("Login error after Google callback:", loginErr);
                return res.redirect(`${process.env.CLIENT_URL}/login?error=Login%20failed`);
            }
            // Redirect to the appropriate dashboard based on role
            const redirectUrl = user.role === 'teacher'
                ? `${process.env.CLIENT_URL}/teacher/dashboard`
                : `${process.env.CLIENT_URL}/student/dashboard`;
            res.redirect(redirectUrl);
        });
    })(req, res, next); // Pass req, res, next to the authenticate function
};

// @desc    Logout user
// @route   GET /api/auth/logout
exports.logout = (req, res, next) => {
    req.logout(function(err) { // req.logout requires a callback in recent Passport versions
        if (err) {
            console.error("Logout error:", err);
            return next(err); // Pass error to Express error handler
         }
        req.session.destroy((err) => { // Ensure session is destroyed
             if (err) {
                console.error("Session destruction error:", err);
             }
             res.clearCookie('connect.sid'); // Optional: Clear session cookie
             // Send a success response or redirect
             // res.redirect(process.env.CLIENT_URL || '/'); // Redirect to client home/login
              res.status(200).json({ message: 'Successfully logged out' }); // Or send JSON response
         });

    });
};


// @desc    Get current logged-in user
// @route   GET /api/auth/current_user
exports.getCurrentUser = (req, res) => {
  if (req.isAuthenticated()) {
     // Send relevant user info, avoid sending sensitive data if any
    res.json({
        _id: req.user._id,
        googleId: req.user.googleId,
        displayName: req.user.displayName,
        email: req.user.email,
        role: req.user.role,
    });
  } else {
    res.status(401).json(null); // Indicate no user is logged in
  }
};